require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const db = require('./db');
const bcrypt = require('bcrypt');
const winston = require('winston');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_in_prod';
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
const LOG_DIR = process.env.LOG_DIR || path.join(__dirname, 'logs');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: path.join(LOG_DIR, 'server.log') }),
    new winston.transports.Console({ format: winston.format.simple() })
  ]
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const safe = path.basename(file.originalname).replace(/\s+/g, '_');
    const filename = Date.now() + '_' + safe;
    cb(null, filename);
  }
});
const upload = multer({ storage });

function createToken(user) {
  return jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '8h' });
}

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'No token' });
  const token = auth.slice(7);
  try {
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ error: 'Forbidden' });
    next();
  };
}

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'username and password required' });
  db.get('SELECT id, username, password, role FROM users WHERE username = ?', [username], async (err, row) => {
    if (err) { logger.error('DB error on login', { err }); return res.status(500).json({ error: 'Internal error' }); }
    if (!row) return res.status(401).json({ error: 'Invalid credentials' });
    const match = await bcrypt.compare(password, row.password);
    if (!match) return res.status(401).json({ error: 'Invalid credentials' });
    const token = createToken(row);
    logger.info('login', { username: row.username, role: row.role });
    res.json({ token, username: row.username, role: row.role });
  });
});

app.get('/api/files', authMiddleware, (req, res) => {
  db.all('SELECT filename, originalname, size, mtime FROM files ORDER BY mtime DESC', [], (err, rows) => {
    if (err) { logger.error('DB error on files', { err }); return res.status(500).json({ error: 'Unable to list files' }); }
    res.json(rows);
  });
});

app.get('/api/files/:filename', authMiddleware, (req, res) => {
  const name = path.basename(req.params.filename);
  const fp = path.join(UPLOAD_DIR, name);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'Not found' });
  res.download(fp);
});

app.post('/api/upload', authMiddleware, requireRole('admin', 'masteradmin'), upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const { filename, originalname, size } = req.file;
  const mtime = Date.now();
  db.run('INSERT INTO files (filename, originalname, size, mtime) VALUES (?, ?, ?, ?)', [filename, originalname, size, mtime], function(err) {
    if (err) { logger.error('DB error insert file', { err }); return res.status(500).json({ error: 'Unable to save file record' }); }
    logger.info('file_uploaded', { by: req.user.username, filename });
    res.json({ success: true, filename });
  });
});

app.delete('/api/files/:filename', authMiddleware, requireRole('masteradmin'), (req, res) => {
  const name = path.basename(req.params.filename);
  const fp = path.join(UPLOAD_DIR, name);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'Not found' });
  fs.unlink(fp, err => {
    if (err) { logger.error('unlink error', { err }); return res.status(500).json({ error: 'Unable to delete' }); }
    db.run('DELETE FROM files WHERE filename = ?', [name], function(err2) {
      if (err2) { logger.error('DB delete error', { err2 }); }
      logger.info('file_deleted', { by: req.user.username, filename: name });
      res.json({ success: true });
    });
  });
});

app.get('/api/ping', (req, res) => res.json({ ok: true }));

app.use('/uploads', express.static(UPLOAD_DIR));

require('./init-db');

app.listen(PORT, () => {
  logger.info(`File server running on http://localhost:${PORT}`);
});
