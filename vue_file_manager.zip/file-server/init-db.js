const db = require('./db');
const bcrypt = require('bcrypt');

db.serialize(async () => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    originalname TEXT NOT NULL,
    size INTEGER NOT NULL,
    mtime INTEGER NOT NULL
  )`);

  const users = [
    { username: 'admin', password: 'admin', role: 'admin' },
    { username: 'masteradmin', password: 'masteradmin', role: 'masteradmin' },
    { username: 'lite', password: 'lite', role: 'lite' }
  ];

  const saltRounds = 10;
  users.forEach(u => {
    db.get('SELECT id FROM users WHERE username = ?', [u.username], async (err, row) => {
      if (err) return console.error(err);
      if (!row) {
        const hash = await bcrypt.hash(u.password, saltRounds);
        db.run('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [u.username, hash, u.role]);
        console.log('Seeded user', u.username);
      }
    });
  });

  console.log('DB init done');
});
