<template>
  <div class="max-w-4xl mx-auto p-6">
    <TopBar v-if="user" :user="user" @logout="logout" />
    <div class="bg-white rounded-lg shadow p-6">
      <div v-if="!token">
        <Login @login="onLogin" />
      </div>
      <div v-else>
        <FileManager :token="token" :role="user.role" />
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue';
import Login from './components/Login.vue';
import FileManager from './components/FileManager.vue';
import TopBar from './components/TopBar.vue';

export default {
  components: { Login, FileManager, TopBar },
  setup() {
    const token = ref(localStorage.getItem('token') || null);
    const user = ref(JSON.parse(localStorage.getItem('user') || 'null'));

    function onLogin({ token: t, user: u }) {
      token.value = t;
      user.value = u;
      localStorage.setItem('token', t);
      localStorage.setItem('user', JSON.stringify(u));
    }
    function logout() {
      token.value = null; user.value = null;
      localStorage.removeItem('token'); localStorage.removeItem('user');
    }

    return { token, user, onLogin, logout };
  }
};
</script>
