<template>
  <div class="flex items-center justify-between mb-4">
    <div>
      <h1 class="text-2xl font-semibold">File Manager</h1>
      <div class="text-sm text-gray-500">Logged as <strong>{{ user.username }}</strong> — {{ user.role }}</div>
    </div>
    <div>
      <button @click="$emit('logout')" class="px-3 py-1 rounded bg-red-500 text-white">Logout</button>
    </div>
  </div>
</template>

<script>
export default { props: ['user'] };
</script>
