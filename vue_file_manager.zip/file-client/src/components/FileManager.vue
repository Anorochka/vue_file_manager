<template>
  <div>
    <div class="flex items-center justify-between mb-4">
      <h2 class="text-lg font-medium">Files</h2>
      <div class="text-sm text-gray-500">Role: <strong>{{ role }}</strong></div>
    </div>

    <div v-if="loading" class="text-gray-600">Loading...</div>

    <div v-else>
      <div v-if="canUpload" class="mb-4">
        <form @submit.prevent="uploadFile" class="flex gap-2 items-center">
          <input type="file" ref="fileInput" />
          <button class="px-3 py-1 bg-green-600 text-white rounded">Upload</button>
        </form>
        <div v-if="uploadError" class="text-red-600 mt-2">{{ uploadError }}</div>
      </div>

      <div v-if="files.length" class="overflow-x-auto">
        <table class="w-full text-left table-auto">
          <thead class="text-sm text-gray-600 border-b">
            <tr>
              <th class="py-2">Filename</th>
              <th class="py-2">Size</th>
              <th class="py-2">Modified</th>
              <th class="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="f in files" :key="f.filename" class="odd:bg-gray-50">
              <td class="py-2">{{ prettyName(f.filename) }}</td>
              <td class="py-2">{{ formatSize(f.size) }}</td>
              <td class="py-2">{{ new Date(f.mtime).toLocaleString() }}</td>
              <td class="py-2">
                <a :href="downloadUrl(f.filename)" class="text-blue-600 mr-3" target="_blank">Download</a>
                <button v-if="canDelete" @click="deleteFile(f.filename)" class="px-2 py-1 bg-red-500 text-white rounded">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div v-else class="text-gray-600">No files uploaded yet.</div>
      <div v-if="error" class="text-red-600 mt-2">{{ error }}</div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import axios from 'axios';
const API = import.meta.env.VITE_API_BASE || 'http://localhost:4000';
export default {
  props: ['token', 'role'],
  setup(props) {
    const files = ref([]);
    const loading = ref(false);
    const error = ref('');
    const uploadError = ref('');
    const fileInput = ref(null);

    const canUpload = props.role === 'admin' || props.role === 'masteradmin';
    const canDelete = props.role === 'masteradmin';

    async function fetchFiles() {
      loading.value = true; error.value = '';
      try {
        const res = await axios.get(`${API}/api/files`, { headers: { Authorization: 'Bearer ' + props.token } });
        files.value = res.data;
      } catch (err) {
        error.value = err.response?.data?.error || 'Network error';
      } finally { loading.value = false; }
    }

    async function uploadFile() {
      uploadError.value = '';
      const fi = fileInput.value;
      if (!fi || !fi.files || fi.files.length === 0) { uploadError.value = 'Choose a file first'; return; }
      const f = fi.files[0];
      const form = new FormData(); form.append('file', f);
      try {
        await axios.post(`${API}/api/upload`, form, { headers: { Authorization: 'Bearer ' + props.token, 'Content-Type': 'multipart/form-data' } });
        await fetchFiles();
        fi.value = '';
      } catch (err) {
        uploadError.value = err.response?.data?.error || 'Upload failed';
      }
    }

    async function deleteFile(filename) {
      if (!confirm('Delete file?')) return;
      try {
        await axios.delete(`${API}/api/files/${encodeURIComponent(filename)}`, { headers: { Authorization: 'Bearer ' + props.token } });
        await fetchFiles();
      } catch (err) {
        alert(err.response?.data?.error || 'Delete failed');
      }
    }

    function prettyName(fn) { const idx = fn.indexOf('_'); if (idx > 0 && /^[0-9]{13,}_/.test(fn)) return fn.slice(idx + 1); return fn; }
    function formatSize(s) { if (s < 1024) return s + ' B'; if (s < 1024*1024) return Math.round(s/1024) + ' KB'; return (s/1024/1024).toFixed(2) + ' MB'; }
    function downloadUrl(fn) { return `${API}/api/files/${encodeURIComponent(fn)}`; }

    onMounted(fetchFiles);
    return { files, loading, error, uploadError, fileInput, fetchFiles, uploadFile, deleteFile, prettyName, formatSize, downloadUrl, canUpload, canDelete };
  }
};
</script>
