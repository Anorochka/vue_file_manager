<template>
  <div class="max-w-md mx-auto">
    <h2 class="text-xl font-medium mb-4">Sign in</h2>
    <form @submit.prevent="submit" class="space-y-3">
      <div>
        <label class="block text-sm mb-1">Username</label>
        <input v-model="username" class="w-full border rounded p-2" />
      </div>
      <div>
        <label class="block text-sm mb-1">Password</label>
        <input type="password" v-model="password" class="w-full border rounded p-2" />
      </div>
      <div>
        <button class="px-4 py-2 bg-blue-600 text-white rounded">Login</button>
      </div>
      <div v-if="error" class="text-red-600">{{ error }}</div>
    </form>
    <div class="mt-4 text-sm text-gray-600">Demo accounts: <strong>admin/admin</strong>, <strong>masteradmin/masteradmin</strong>, <strong>lite/lite</strong></div>
  </div>
</template>

<script>
import axios from 'axios';
const API = import.meta.env.VITE_API_BASE || 'http://localhost:4000';
export default {
  data() { return { username: '', password: '', error: '' }; },
  methods: {
    async submit() {
      this.error = '';
      try {
        const res = await axios.post(`${API}/api/login`, { username: this.username, password: this.password });
        const data = res.data;
        this.$emit('login', { token: data.token, user: { username: data.username, role: data.role } });
      } catch (err) {
        this.error = err.response?.data?.error || 'Network error';
      }
    }
  }
};
</script>
