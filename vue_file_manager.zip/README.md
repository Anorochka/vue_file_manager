# Vue File Manager — Full (Docker)

Локальный проект: frontend (Vue 3 + Tailwind) + backend (Express + SQLite). Включает роли, логирование и Docker Compose для быстрого старта.

## Быстрый запуск (Docker)
1. Запустить:
   ```
   docker-compose up --build
   ```
2. Открыть фронтенд: http://localhost:5173/
3. API: http://localhost:4000/

Демо-аккаунты:
- admin/admin
- masteradmin/masteradmin
- lite/lite
